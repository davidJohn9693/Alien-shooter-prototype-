var bg, bgImg
var bottomGround
var topGround
var plane, planeImg
var plane2, plane2Img
var plane3, plane3Img

var alien, alienImg, alienG
var alien2, alien2Img, alien2G
var boss, bossImg
var bullet1, bullet2, bullet1Img, bullet2Img, bulletG

var score;

function preload(){
  bgImg = loadImage("assets/bg.jpg")

  planeImg = loadImage("assets/plane1.png")
  plane2Img = loadImage("assets/plane2.png")
  plane3Img = loadImage("assets/plane3.png")

  alienImg = loadImage("assets/alien1.png")
  alien2Img = loadImage("assets/alien2.png")

  bossImg = loadImage("assets/boss.png")

  bullet1Img = loadImage("assets/bullet.png")
  bullet2Img = loadImage("assets/bullet2.png")
}

function setup(){

createCanvas(1200,650)

//background image
bg = createSprite(600,350,1,1);
bg.addImage(bgImg);
bg.scale = 0.45  

//creating top and bottom grounds
bottomGround = createSprite(200,390,800,20);
bottomGround.visible = false;

topGround = createSprite(200,10,800,20);
topGround.visible = false;
      
//creating plane     
plane = createSprite(150,200,20,50);
plane.addImage("plane",plane2Img);
plane.scale = 0.5   
plane.rotation = 90

alienG = new Group()
alien2G = new Group();
bulletG = new Group();


}

function draw() {
        
      //making the plane jump
      if(keyDown("space")) {
        plane.velocityY -= 3 ;
      }
      

      //creating alien
      if(frameCount % 100 == 0){
        randomN = Math.round(random(0,1))
      

        if(randomN == 0){
          alien = createSprite(1050, random(50, 600), 20, 20);
          alien.addImage("alien",alienImg);
          alien.scale = 0.4
          alien.velocityX = -1.5
          alienG.add(alien)
          alien.debug = true

          if(alienG.isTouching(bulletG)){
 

            for(var i=0;i<alienG.length;i++){     
                 
             if(alienG[i].isTouching(bulletG)){
                  alienG[i].destroy()
                  bulletG.destroyEach()
                  } 
            }
           }
           
        }

        else{
            alien2 = createSprite(1050, random(50, 600), 20, 20);
            alien2.addImage("alien2",alien2Img);
            alien2.scale = 0.4 
            alien2.velocityX = -0.7
            alienG.add(alien2)
            alien2.debug = true

            bulletG.overlap(alienG, function(collector, collected) {
              collected.remove();
              console.log("collided")
            })
        }

      }     

      //adding gravity  
      plane.velocityY = plane.velocityY + 1.5;
      
      drawSprites();
}

function mousePressed(){
  bullet1 = createSprite(plane.x + 30, plane.y, 20, 20);
  bullet1.addImage("bullet", bullet1Img)
  bullet1.scale = 0.2
  bullet1.velocityX = 20
  bulletG.add(bullet1)
  bullet1.debug = true
  
}